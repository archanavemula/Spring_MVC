package com.spring.ase.command;

import org.springframework.ui.Model;

public interface ICommand {

	public void execute(Model model);
	
}
 